//
//  GcodesTableTableViewController.swift
//  AM3D
//
//  Created by admin on 08/05/18.
//  Copyright © 2018 Monkey Software. All rights reserved.
//

import UIKit

class GcodesTableTableViewController: UITableViewController, NSXMLParserDelegate {

    
    @IBOutlet var tdData: UITableView!
    var parser = NSXMLParser();
    //vector per guardar parelles de dades
    var posts = NSMutableArray();
    //per guardar el conjunt de dades
    var elements = NSMutableDictionary();
    var element = NSString();
    var field00 = NSMutableString();
    var field02 = NSMutableString();
    var isNotError: Bool = false;

    override func viewDidLoad() {
        super.viewDidLoad()
        self.beginParsing()

        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func beginParsing(){
        posts = [];
        
        //lectura fitxer xml xarxa
        parser = NSXMLParser(contentsOfURL: (NSURL(string: "http://oracle.ilerna.com:8126/projectdam/servei.php?db=MonkeySoftware_Monkey&user=DAM2_Monkey&pass=SpaghettiMonkey2018&tipo=2&consulta=select*from%20gcode"))!)!;
        parser.delegate = self;
        parser.parse();
        //lectura fitxer xml local
        /*if let path = NSBundle.mainBundle().URLForResource("xml", withExtension: "xml"){
         if let parser = NSXMLParser(contentsOfURL: path){
         parser.delegate = self;
         parser.parse();
         }
         
         }*/
        tdData.reloadData();
    }
    
    //1 s'executa quan troba l'entrada "item"
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        //atribut
        if(elementName as NSString).isEqualToString("registres"){
            var resultat = attributeDict["estat"]! as String;
            if(resultat == "200"){
                //si tot ok continuo, sino out
                isNotError = true;
            }else{
                print("Error!");
            }
        }
        if(isNotError){
            element = elementName;
            if(elementName as NSString).isEqualToString("registre"){
                elements = NSMutableDictionary();
                elements = [:];
                field00 = NSMutableString();
                field00 = "";
                field02 = NSMutableString();
                field02 = "";
            }
        }
        
    }
    
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if(isNotError){
            if(elementName as NSString).isEqualToString("registre"){
                if !field00.isEqual(nil){
                    elements.setObject(field00, forKey: "field00");
                }
                if !field02.isEqual(nil){
                    elements.setObject(field02, forKey: "field02");
                }
                
                posts.addObject(elements);
            }
        }
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String)
    {
        if(isNotError){
            if(element.isEqualToString("field00")){
                field00.appendString(string);
            }else if element.isEqualToString("field02"){
                field02.appendString(string);
            }
        }
        
    }

    
    
    
    
    

    // MARK: - Table view data source
/*
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return posts.count;
    }*/

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return posts.count;
    }

    
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        var cell: UITableViewCell = tableView.dequeueReusableCellWithIdentifier("Cell")!;

        //seleccionar taula dins TdData (a la jerarquia del main) i ficar identifier a "Cell"
        cell.textLabel?.text = posts.objectAtIndex(indexPath.row).valueForKey("field00") as! NSString as String;
        cell.detailTextLabel?.text = posts.objectAtIndex(indexPath.row).valueForKey("field02") as! NSString as String;
        return cell as UITableViewCell;
    }
    

    /*
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    */

    /*
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            tableView.deleteRowsAtIndexPaths([indexPath], withRowAnimation: .Fade)
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    */

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
