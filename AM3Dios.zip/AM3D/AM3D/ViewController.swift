//
//  ViewController.swift
//  AM3D
//
//  Created by admin on 23/04/18.
//  Copyright © 2018 Monkey Software. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet var titol: UILabel!
    var usuari: NSString = "";
    var titol2: String = "";
    override func viewDidLoad()
    {
        super.viewDidLoad()
        titol.text = "Benvingut " + (usuari as String);
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

