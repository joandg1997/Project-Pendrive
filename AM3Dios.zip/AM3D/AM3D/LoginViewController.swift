//
//  LoginViewController.swift
//  AM3D
//
//  Created by admin on 07/05/18.
//  Copyright © 2018 Monkey Software. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController,NSXMLParserDelegate {


    @IBOutlet var btEntrar: UIButton!
    @IBOutlet var contrasenya: UITextField!
    @IBOutlet var usuari: UITextField!
    var parser = NSXMLParser();
    //vector per guardar parelles de dades
    var posts = NSMutableArray();
    //per guardar el conjunt de dades
    var elements = NSMutableDictionary();
    var element = NSString();
    var field00 = NSMutableString();
    var isNotError: Bool = false;
    var entrar: Bool = false
    var password: String = "";
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
            if(segue.identifier == "entrarrr"){
                var segundaView: ViewController = segue.destinationViewController as! ViewController;
                segundaView.usuari = usuari.text!;
            }
    }
    
    @IBAction func entrar(sender: UIButton) {
        password = contrasenya.text!;
        beginParsing();
        if(entrar==true){
            performSegueWithIdentifier("entrarrr", sender: nil)
        }else{
            let alert = UIAlertView()
            alert.title = "Login"
            alert.message = "ERROR, Usuari o contrasenya no coincideix"
            alert.addButtonWithTitle("Ok")
            alert.show()
        }
    }
    func beginParsing(){
        posts = [];
        
        //lectura fitxer xml xarxa
        parser = NSXMLParser(contentsOfURL: (NSURL(string: "http://oracle.ilerna.com:8126/projectdam/servei.php?db=MonkeySoftware_Usuaris&user=DAM2_Monkey&pass=SpaghettiMonkey2018&tipo=2&consulta=SELECT%20nickname%20FROM%20Users%20WHERE%20nickname%20=%20%27"+usuari.text!+"%27%20AND%20Convert(varchar,DECRYPTBYPASSPHRASE(%27Banana%27,%20contrasenya))%20=%20%27"+password+"%27"))!)!;
        parser.delegate = self;
        parser.parse();
        //lectura fitxer xml local
        /*if let path = NSBundle.mainBundle().URLForResource("xml", withExtension: "xml"){
         if let parser = NSXMLParser(contentsOfURL: path){
         parser.delegate = self;
         parser.parse();
         }
         
         }*/
    }
    
    //1 s'executa quan troba l'entrada "item"
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        //atribut
        if(elementName as NSString).isEqualToString("registres"){
            var resultat = attributeDict["estat"]! as String;
            if(resultat == "200"){
                //si tot ok continuo, sino out
                isNotError = true;
            }else{
                print("Error!");
            }
        }
        if(isNotError){
            element = elementName;
            if(elementName as NSString).isEqualToString("registre"){
                elements = NSMutableDictionary();
                elements = [:];
                field00 = NSMutableString();
                field00 = "";
            }
        }
        
    }
    
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?)
    {
        if(isNotError){
            if(elementName as NSString).isEqualToString("registre"){
                if !field00.isEqual(nil){
                    elements.setObject(field00, forKey: "field00");
                }
                posts.addObject(elements);
                entrar = true;
                
            }
        }
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String)
    {
        if(isNotError){
            if(element.isEqualToString("field00")){
                field00.appendString(string);
        }
        
        }
    }
}