//
//  InsertarGcodeViewController.swift
//  AM3D
//
//  Created by admin on 08/05/18.
//  Copyright © 2018 Monkey Software. All rights reserved.
//

import UIKit

class InsertarGcodeViewController: UIViewController, NSXMLParserDelegate {

    @IBOutlet var btInsertar: UIButton!
    @IBOutlet var contingut: UITextField!
    @IBOutlet var nomArxiu: UITextField!
    var parser = NSXMLParser();
    //per guardar el conjunt de dades
    var elements = NSMutableDictionary();
    var element = NSString();
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    @IBAction func onClickInsertar(sender: UIButton) {
        self.beginParsing()
    }
    func beginParsing(){
        //lectura fitxer xml xarxa
        parser = NSXMLParser(contentsOfURL: (NSURL(string: "http://oracle.ilerna.com:8126/projectdam/servei.php?db=MonkeySoftware_Monkey&user=DAM2_Monkey&pass=SpaghettiMonkey2018&tipo=1&consulta=INSERT%20INTO%20GCODE%20VALUES(%27"+nomArxiu.text!+"%27,null,%27"+contingut.text!+"%27,%27michael93%27)"))!)!;
        parser.delegate = self;
        parser.parse();
        //lectura fitxer xml local
        /*if let path = NSBundle.mainBundle().URLForResource("xml", withExtension: "xml"){
         if let parser = NSXMLParser(contentsOfURL: path){
         parser.delegate = self;
         parser.parse();
         }
         
         }*/
    }
    
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String])
    {
        //atribut
        if(elementName as NSString).isEqualToString("registres"){
            var resultat = attributeDict["estat"]! as String;
            if(resultat == "200"){
                let alert = UIAlertView()
                alert.title = "Resultat"
                alert.message = "S'ha insertat tot correctament"
                alert.addButtonWithTitle("Ok")
                alert.show()
                nomArxiu.text=""
                contingut.text=""
            }else{
                let alert = UIAlertView()
                alert.title = "Resultat"
                alert.message = "ERROR al insertar"
                alert.addButtonWithTitle("Ok")
                alert.show()
            }
        }
    }


    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
